import xlrd
import datetime
import xlwt
from xlutils.copy import copy
import os.path
import ConfigParser
from sikuli import *
import logging
from logging.handlers import RotatingFileHandler
config = ConfigParser.ConfigParser()
configFile = sys.argv[1]
#configFile = "C:\\birakesh\\APO\\ConfigFile"
config.read(configFile)
BOTLog = config.get('SectionOne','BOTLog')
python = config.get('SectionOne','python')
#pyscript = config.get('SectionOne','pyscript')
errorEmail = config.get('SectionOne','errorEmail')
if os.path.exists(BOTLog):
    os.remove(BOTLog)
logger = logging.getLogger("Rotating Log")
logger.setLevel(logging.INFO)
handler = RotatingFileHandler(BOTLog, maxBytes=100000,backupCount=40)
logger.addHandler(handler)
MASTEREXCEL = config.get('SectionOne','MASTEREXCEL')
EXCELFILE = config.get('SectionOne','EXCELFILE')
PROJECTNAME = config.get('SectionOne','ProjectName')
EXPORTEXCEL = config.get('SectionOne','ExportExcel')
CONFEXCEL = config.get('SectionOne','ConfExcel')
SendToAPOImg = config.get('SectionOne','SendToAPOImg')
DeleteInAPOImg = config.get('SectionOne','DeleteInAPOImg')
SendToR3Img = config.get('SectionOne','SendToR3Img')
DeleteInR3Img = config.get('SectionOne','DeleteInR3Img')
TickImg = config.get('SectionOne','TickImg')
now = datetime.datetime.now()
CurrentTime = now.strftime("%d.%m.%Y")  
 

print(EXPORTEXCEL)
FormName = []
print(MASTEREXCEL)
book = xlrd.open_workbook(MASTEREXCEL)
sheet = book.sheet_by_index(0)
keywords = []
print(sheet.ncols)
print(sheet.nrows)
def changed(event):
    print "something changed in ", event.region
    for ch in event.changes:
        ch.highlight() # highlight all changes
    sleep(1)
    for ch in event.changes:
        ch.highlight() # turn off the highlights
    Settings.isChanged = True
    event.region.stopObserver()
w = SCREEN.getW()
h = SCREEN.getH()

def Click(keywords):
    keywords = keywords.split(",")
    for text in keywords:
        text = str(text)
        text1 = text.replace('-',' ')
        match = findText(text1)
        logger.info("Clicking : "+(text1))
        click(match)
        wait(3)
def Wait(time):
    logger.info("Waiting for "+(time)+" secs")
    time = int(time)
    wait(time)    
def checkError():
    logger.info("Checking for an error")
    w=SCREEN.getW()
    h=SCREEN.getH()
    imageToText = config.get('SectionOne','imageToText')
    imgWithText = Image.create(capture(Region(0,0,w,h)))
    ar= Image(imgWithText.resize(2))
    res = ar.text()
    res = res.encode("utf-8")
    f = open(imageToText, "w")
    f.write(res)
    f.close()
    errorFound = False 
    with open(imageToText, 'r+') as f:
        lines = f.readlines()
        for i in range(0, len(lines)):
                line = lines[i]
                if "Error" in line or "Invalid" in line:
                    logger.info("Error Found : "+(line))
                    errorFound = True
                    break
    f.close()
    return errorFound
def login():
    logger.info("Logging in")
    Explorer = config.get('SectionOne','Explorer')
    openApp(Explorer)
    wait(6)
    type("l", KeyModifier.CTRL)
    logger.info("Entering URL : ")
    EBSUrl = config.get('SectionOne','EBSUrl')
    type(EBSUrl)
    type(Key.ENTER)
    wait(15)
ModuleList = []
sleep(3)


def PerformKeyStrokes(sheet):
    for row_index in range(sheet.nrows):
        keyDown(Key.ALT)
        type(Key.SPACE)
        keyUp(Key.ALT)
        type("x")
        for col_index in range(sheet.ncols):
            if sheet.cell(row_index, col_index).value == '':
                continue
                sleep(5)
            else:
                cell_value = sheet.cell(row_index, col_index).value
                cell_value = cell_value.split(' ')
                if(cell_value[0]=="openApplet"):
                    openApplet()
                elif(cell_value[0]=="Wait:"):
                    Wait(cell_value[1])
                elif(cell_value[0]=="Date:"):
                    type(CurrentTime) 
                elif(cell_value[0]=="Click:"):
                    keywords = cell_value[1]
                    print(keywords)
                    Click(keywords)
                elif(cell_value[0]=="Login:"):
                  #  keywords = cell_value[1]
                    count = 0
                    for i in range(0,3):
                        login()
                        errorFound = checkError()
                        if errorFound == True:
                            count = count +1
                        else:
                            break
                        if count == 3:
                            cmd = "%s %s %s" % (python, pyscript,excel)
                            result = run(cmd)
                elif(cell_value[0]=="Type:"):
                    print(cell_value)
                    for char_index in range(1,len(cell_value)):
                        logger.info("Print"+(cell_value[char_index]))                    
                        type(cell_value[char_index]+" ")
                    if len(cell_value) > 2:
                        type(Key.BACKSPACE)
                    sleep(5)
                elif(cell_value[0]=="Key:"):
                    print(cell_value)
                    key_up = ''
                    for char_index in range(1,len(cell_value)):
                        key = cell_value[char_index]
                        if(key == "ALT" or key == "CTRL" or key == "SHIFT"): 
                            if(cell_value[char_index]=="ALT"):
                                logger.info("Pressing ALT")
                                keyDown(Key.ALT)
                                key_up = "ALT"
                            elif(cell_value[char_index]=="CTRL"):
                                logger.info("Pressing CTRL")
                                keyDown(Key.CTRL)
                                key_up = "CTRL"
                            elif(cell_value[char_index]=="SHIFT"):
                                logger.info("Pressing SHIFT")
                                keyDown(Key.SHIFT)
                                key_up = "SHIFT"
                        elif(key == "ENTER" or Key == "BACKSPACE" or key=="TAB" or key=="SPACE" or key=="DOWN" or key=="UP" or key=="RIGHT" or key=="LEFT"):
                            if(key == "ENTER"):
                                logger.info("Pressing ENTER")
                                type(Key.ENTER)
                                sleep(1)
                            elif(key == "BACKSPACE"):
                                logger.info("Pressing BACKSPACE")
                                type(Key.BACKSPACE)
                                sleep(1)
                            elif(key == "SPACE"):
                                logger.info("Pressing SPACE")
                                type(Key.SPACE)
                                sleep(1)
                            elif(key == "TAB"):
                                logger.info("Pressing TAB")
                                type(Key.TAB)
                                sleep(1)
                            elif(key == "DOWN"):
                                logger.info("Pressing DOWN")
                                type(Key.DOWN)
                            elif(key == "UP"):
                                logger.info("Pressing UP")
                                type(Key.UP)
                            elif(key == "RIGHT"):
                                logger.info("Pressing RIGHT")
                                type(Key.RIGHT)
                            elif(key == "LEFT"):
                                logger.info("Pressing LEFT")
                                type(Key.LEFT)
                                sleep(1)
                        elif(cell_value[char_index]>='a' and cell_value[char_index]<='z'):
                                logger.info("Press"+(cell_value[char_index]))
                                type(cell_value[char_index])
                        elif(key[0]=='F'):
                            print(cell_value[char_index])
                            key = cell_value[char_index]
                            print(key)
                            logger.info("Pressing"+(key))
                            if(key == "F1"):
                                type(Key.F1)
                            elif(key == "F2"):
                                type(Key.F2)
                            elif(key == "F3"):
                                type(Key.F3)
                            elif(key == "F4"):
                                type(Key.F4)
                            elif(key == "F5"):
                                type(Key.F5)
                            elif(key == "F6"):
                                type(Key.F6)
                            elif(key == "F7"):
                                type(Key.F7)
                            elif(key == "F8"):
                                type(Key.F8)
                            elif(key == "F9"):
                                type(Key.F9)
                            elif(key == "F10"):
                                type(Key.F10)
                            elif(key == "F11"):
                                type(Key.F11)
                                sleep(5)
                            elif(key == "F12"):
                                type(Key.F12)
                    if(key_up == "ALT"):
                        keyUp(Key.ALT)               
                    elif(key_up == "CTRL"):
                        keyUp(Key.CTRL)
                    elif(key_up == "SHIFT"):
                        keyUp(Key.SHIFT)
                    sleep(6)

logger.info("Reading the MASTER Excel file")
for row_index in range(sheet.nrows):
    for col_index in range(sheet.ncols):
        cell_value = sheet.cell(row_index, col_index).value
        logger.info("Module is : "+(cell_value))
        ModuleList.append(cell_value)
print(ModuleList)
#wb.save(OUTPUTEXCEL) 
for index in range(len(ModuleList)):
    logger.info("Reading the module: "+(ModuleList[index])) 
    excel = EXCELFILE + ModuleList[index]
    book = xlrd.open_workbook(excel)
    tab = (ModuleList[index]).split('.')
    tab = tab[0]
    sheet = book.sheet_by_index(0)
    PerformKeyStrokes(sheet)                    
ExportBook = xlrd.open_workbook(EXPORTEXCEL)
ExportSheet = ExportBook.sheet_by_index(0)
variantCount = ExportSheet.nrows -1
row_num = 1
print(variantCount)
while (variantCount > 0):
    if variantCount == 0:
        for i in range(0,3):
            type(Key.TAB)
            sleep(1)
        type(Key.DOWN)
    else:
        type(Key.LEFT)
        type(Key.RIGHT)
    variantCount = variantCount -1
    engagement = ExportSheet.col_values(0)[row_num]
    row_num = row_num + 1
    hover("1578557425725-1.png")
    sleep(2)
    doubleClick("1578557425725.png")  
    while not exists("1580464340069.png"):
        wait(1)
   # for i in range(0,15):
   #     type(Key.TAB)
 #       wait(1)
 #   type(Key.ENTER)
    click("1580464340069.png")
    sleep(2)
    hover("1578552179731.png")
    sleep(3)
    if not exists("1578551688496-1.png"):
        doubleClick("1580983465361-1.png")
        doubleClick("1580983465361-1.png")
        doubleClick("1580983465361-1.png")
        doubleClick("1580983465361-1.png")
        doubleClick("1580983465361-1.png")
    sleep(2)
    click("1578551688496.png")
    wait(1)
    click("1578552003169.png")
    sleep(1)
    z = findAll("1578552179731.png")
    selectionCount = 0
    changedCount = 0
    for icon in z:
        click(icon)
        if exists(Pattern("1554287103294.png").similar(0.90)):
            continue
        if exists(Pattern("1578555289512.png").similar(0.90)):
            continue        
        sleep(1)
        click("1578552725488.png")
        sleep(1)        
        if exists(Pattern("1580733149556.png").similar(0.95)):
            print ("enterd into 182")
            while not exists("1579856487009.png"):
                print("In Loop")
                click(SendToR3Img)
                sleep(2)
            type(Key.ENTER)
            sleep(5)
            type(Key.ENTER)
            while exists("1579856487009.png"):
                click("1579856487009.png")
            if exists("1579856487009.png"):
                click("1579856487009.png")
            continue
        changedCount = 0
        bigScreenReg =  Region(431,150,800,300)
        r = bigScreenReg
        print ("in deleteapo")
        r.onChange(80, changed)
        hover(DeleteInAPOImg)
        Settings.isChanged = False        
        r.observe(5) # observing for 5 seconds (script pauses here)       
        if Settings.isChanged: # check wether the handler was called (because there where changes)
            print "there where changes"
            getmouseLoc = Env.getMouseLocation()
            x = getmouseLoc.getX()
            y = getmouseLoc.getY()
            print x
            print y
            changedCount = changedCount + 1       
        if not exists("1578554123192-1.png"):
            click("1578552725488.png")     
        sleep(5)
        bigScreenReg =  Region(431,150,800,300)
        r = bigScreenReg
        r.onChange(80, changed)
        hover(SendToAPOImg)
        Settings.isChanged = False        
        r.observe(7) # observing for 5 seconds (script pauses here)       
        if Settings.isChanged: # check wether the handler was called (because there where changes)
            print "there where changes"
            getmouseLoc = Env.getMouseLocation()
            x = getmouseLoc.getX()
            y = getmouseLoc.getY()
            print x
            print y
            changedCount = changedCount + 1
        if not exists("1578554123192-1.png"):
            click("1578552725488.png")
        sleep(5)
        bigScreenReg =  Region(431,150,800,300)
        r = bigScreenReg
        r.onChange(80, changed)
        hover(DeleteInR3Img)
        Settings.isChanged = False        
        r.observe(7) # observing for 5 seconds (script pauses here)       
        if Settings.isChanged: # check wether the handler was called (because there where changes)
            print "there where changes"
            getmouseLoc = Env.getMouseLocation()
            x = getmouseLoc.getX()
            y = getmouseLoc.getY()
            print x
            print y
            changedCount = changedCount + 1
        if not exists("1578554123192-1.png"):
            click("1578552725488.png")
        sleep(5)
        
        bigScreenReg =  Region(431,150,800,300)
        r = bigScreenReg
        r.onChange(80, changed)
        hover(SendToR3Img)
        Settings.isChanged = False        
        r.observe(7) # observing for 5 seconds (script pauses here)       
        if Settings.isChanged: # check wether the handler was called (because there where changes)
            print "there where changes"
            getmouseLoc = Env.getMouseLocation()
            x = getmouseLoc.getX()
            y = getmouseLoc.getY()
            print x
            print y
            changedCount = changedCount + 1
        print changedCount
        if (changedCount == 1):
            selectionCount = selectionCount + 1
            click(Location(x,y))
            sleep(2)
            print("Selection Count ")
            print(selectionCount)
            if (selectionCount >= 1):
                while not exists("1579856487009.png"):
                    print("In Loop")
                    click(Location(x,y))
                    sleep(2)
                type(Key.ENTER)
                sleep(5)
                type(Key.ENTER)
                while exists("1579856487009.png"):
                    click("1579856487009.png")
            if exists("1579856487009.png"):
                click("1579856487009.png")
            
        elif (changedCount == 2):
            cmd = "%s %s %s %s" % (python, errorEmail,engagement, EXPORTEXCEL )
            result = run(cmd)
            print("YES")
            sleep(3)
    sleep(20)
    keyDown(Key.SHIFT)
    type(Key.F9)
    keyUp(Key.SHIFT)
    sleep(10)
    type(Key.F3)    
    sleep(10)
    while not exists("1580729314531.png"):
        type(Key.F3)
        wait(1)
    excel = CONFEXCEL
    book = xlrd.open_workbook(excel)
    tab = (ModuleList[index]).split('.')
    tab = tab[0]
    sheet = book.sheet_by_index(0)
    PerformKeyStrokes(sheet)                    
