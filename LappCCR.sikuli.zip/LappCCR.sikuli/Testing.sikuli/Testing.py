z = findAll("1578552179731.png")
for icon in z:
    click(icon)


