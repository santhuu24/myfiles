if not exists("1578551688496.png"):
    print ("enteerd")
    doubleClick("1580983465361.png")
    doubleClick("1580983465361.png")
    doubleClick("1580983465361.png")
    doubleClick("1580983465361.png")
    doubleClick("1580983465361.png")
    
